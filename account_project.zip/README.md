"# lara10" 
"# lara10"  git init git add README.md git commit -m "first commit" git branch -M main git remote add origin https://github.com/dukeputu/lara10.git git push -u origin main
