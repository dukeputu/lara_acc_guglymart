
<?php $__env->startSection('title', 'Search Results'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .search-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        border-radius: 15px;
        margin-bottom: 30px;
    }

    .search-form {
        background: white;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        margin-bottom: 30px;
    }

    .user-result-card {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 15px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
    }

    .user-result-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.15);
    }

    .result-stat {
        display: inline-block;
        margin-right: 20px;
        padding: 5px 10px;
        background: #f8f9fa;
        border-radius: 5px;
        font-size: 14px;
    }
</style>

<div class="container-fluid">
    <!-- Header -->
    <div class="search-header">
        <h1>🔍 Search Users</h1>
        <p class="mb-0">Find users by name, phone, level, or business volume</p>
    </div>

    <!-- Search Form -->
    <div class="search-form">
        <form action="<?php echo e(route('admin.mlm.search')); ?>" method="GET">
            <div class="row">
                <div class="col-md-3">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Search by name" value="<?php echo e(request('name')); ?>">
                </div>
                <div class="col-md-3">
                    <label>Phone Number</label>
                    <input type="text" name="phone" class="form-control" placeholder="Search by phone" value="<?php echo e(request('phone')); ?>">
                </div>
                <div class="col-md-2">
                    <label>Level</label>
                    <select name="level" class="form-control">
                        <option value="">All Levels</option>
                        <?php for($i=0; $i<=10; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('level') == $i ? 'selected' : ''); ?>>
                                Level <?php echo e($i); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Min Business</label>
                    <input type="number" name="min_business" class="form-control" placeholder="₹ Min" value="<?php echo e(request('min_business')); ?>">
                </div>
                <div class="col-md-2">
                    <label>&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <a href="<?php echo e(route('admin.mlm.search')); ?>" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </a>
                    <a href="<?php echo e(route('admin.mlm.tree')); ?>" class="btn btn-info">
                        <i class="fas fa-sitemap"></i> Back to Tree
                    </a>
                </div>
            </div>
        </form>
    </div>

    <!-- Search Results -->
    <div class="mb-3">
        <h5>
            Found <?php echo e($users->total()); ?> user(s)
            <?php if(request()->anyFilled(['name', 'phone', 'level', 'min_business'])): ?>
                matching your criteria
            <?php endif; ?>
        </h5>
    </div>

    <?php if($users->count() > 0): ?>
        <div class="results-container">
            <?php $__currentLoopData = $usersWithData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($userData): ?>
                <div class="user-result-card">
                    <div class="row align-items-center">
                        <div class="col-md-3">
                            <h5 class="mb-1"><?php echo e($userData['name']); ?></h5>
                            <p class="text-muted mb-0">
                                📞 <?php echo e($userData['phone']); ?><br>
                                🆔 ID: #<?php echo e($userData['user_id']); ?>

                            </p>
                        </div>
                        <div class="col-md-6">
                            <span class="result-stat">
                                <strong>💰 Total Business:</strong> ₹<?php echo e(number_format($userData['total_business'], 0)); ?>

                            </span>
                            <span class="result-stat">
                                <strong>🏆 Level:</strong> 
                                <span class="badge bg-primary"><?php echo e($userData['qualified_level']); ?></span>
                            </span>
                            <span class="result-stat">
                                <strong>📊 Top Leg:</strong> <?php echo e($userData['top_leg_percentage']); ?>%
                            </span>
                            <?php if($userData['qualified_level'] >= 4): ?>
                            <span class="result-stat">
                                <strong>🔐 40:60:</strong> 
                                <span class="badge <?php echo e($userData['is_4060_compliant'] ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e($userData['ratio_status']); ?>

                                </span>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-3 text-end">
                            <a href="<?php echo e(route('admin.mlm.userReport', $userData['user_id'])); ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-eye"></i> View Details
                            </a>
                        </div>
                    </div>
                    
                    <!-- Additional Info -->
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <small class="text-muted">
                                💼 Self Business: ₹<?php echo e(number_format($userData['self_business'], 0)); ?> | 
                                💵 Monthly Salary: ₹<?php echo e(number_format($userData['salary'], 0)); ?> | 
                                📈 Next Level Need: ₹<?php echo e(number_format($userData['business_needed'], 0)); ?>

                            </small>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($users->appends(request()->query())->links()); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> No users found matching your search criteria.
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\trade-mania\resources\views/admin/search_results.blade.php ENDPATH**/ ?>