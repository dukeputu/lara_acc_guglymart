 <footer class="modern-header" style=" top: unset; ">
        <div class="pull-right hidden-xs">
          <b>Version</b> 8.2721
        </div>
        <strong>Copyright &copy; 2025-2026.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->
 <?php /**PATH D:\laragon\www\goglyMart\account_project\resources\views/userApp/layouts/partials/footer.blade.php ENDPATH**/ ?>