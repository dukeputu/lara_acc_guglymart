
<?php $__env->startSection('title', 'Income List'); ?>

<?php $__env->startSection('content'); ?>


<div class="container">
    <h3>Wallet Transfer History</h3>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>From</th>
                <th>To</th>
                <th>Amount</th>
                <th>Last Wallet Balance</th>
                <th>Time</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isCredit = session('member_id') === $row->to_member_id;
                    $amountText = $isCredit ? '+'.$row->amount.' Cr' : '-'.$row->amount.' Dr';
                    $balance = $isCredit ? $row->to_member_balance : $row->from_member_balance;

                    $fromName = \App\Models\Member::where('member_id', $row->from_member_id)->value('name');
                    $toName = \App\Models\Member::where('member_id', $row->to_member_id)->value('name');
                ?>
                <tr>
                    <td><?php echo e($fromName); ?> [<?php echo e($row->from_member_id); ?>]</td>
                    <td><?php echo e($toName); ?> [<?php echo e($row->to_member_id); ?>]</td>
                    <td class="<?php echo e($isCredit ? 'text-success' : 'text-danger'); ?>"><strong><?php echo e($amountText); ?></strong></td>
                    <td><?php echo e($balance); ?></td>
                    <td><?php echo e(date('d-m-Y H:i', strtotime($row->created_at))); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\MLMLara\backend\resources\views/admin/wallet/history.blade.php ENDPATH**/ ?>