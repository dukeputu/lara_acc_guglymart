<?php
    echo 'p';
?><?php /**PATH D:\laragon\www\goglyMart\account_project\resources\views/userApp/userAppView/dashboard.blade.php ENDPATH**/ ?>