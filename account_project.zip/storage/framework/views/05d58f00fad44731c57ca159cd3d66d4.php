
<?php echo $__env->make('userApp.layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('userApp.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->yieldContent('content'); ?>
 
    
<?php echo $__env->make('userApp.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH D:\laragon\www\goglyMart\trade-mania\resources\views/userApp/layouts/userAppLayout.blade.php ENDPATH**/ ?>