<!-- Left side column. contains the logo and sidebar -->
<style>
    .sidebar .label {
        font-size: 11px;
        margin-left: 10px;
    }
</style>

<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            
            <div class="pull-left info">

                <a class=" logoutUser" href="<?php echo e(url('/logout')); ?>"
                    style=" background: tomato; padding: 4px 11px; border-radius: 10px; ">Logout</a>

                <a class=" logoutUser" href="<?php echo e(route('userLogin.app')); ?>"
                    style=" background: blue; padding: 4px 11px; border-radius: 10px; " target="_blank">User</a>


            </div>
            
        </div>

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <!-- <li class="active treeview"> -->
            <li class=" treeview">
                <a href="<?php echo e(url('/dashboard')); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>

            </li>

            <li class="treeview">

                <a href="javascript:void(0)">
                    <i class="fa fa-users"></i> <span>Admin List</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu" style="display: none;">
                    <li>
                        <a href="<?php echo e(route('addAdmin.adminCreate')); ?>">
                            <i class="fa fa-circle-o"></i> Add Admin
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('viewAdmins.list')); ?>">
                            <i class="fa fa-circle-o"></i> View Admins List
                        </a>
                    </li>

                </ul>
            </li>


            <li class=" treeview">
                <a href="<?php echo e(route('packageMaster.list')); ?>">
                    <i class="fa fa-file"></i> <span>Package Master</span>
                </a>

            </li>
            <li class=" treeview">
                <a href="<?php echo e(route('appUsers.listAdminPanel')); ?>">
                    <i class="fa fa-file"></i> <span>App Users</span>



                </a>

            </li>
            </li>
            <li class=" treeview">
                <a href="<?php echo e(route('addBalanceRequest.list')); ?>">
                    <i class="fa fa-file"></i> <span>Add Balance Request</span>

                    <?php
                        $renewCount = \DB::table('user_balance_request')->where('status', 2)->count();

                        $withdrawalCount = \DB::table('user_withdraw_request')->where('status', 2)->count();
                    ?>
                    <?php if($renewCount > 0): ?>
                        <small class="label pull-right bg-yellow"><?php echo e($renewCount); ?></small>
                    <?php endif; ?>

                </a>

            </li>

            </li>
            <li class=" treeview">
                <a href="<?php echo e(route('packageBuyingRequest.list')); ?>">
                    <i class="fa fa-file"></i> <span>Package Buying </span>
                </a>

            </li>

            </li>
            <li class=" treeview">
                <a href="<?php echo e(route('withdrawalRequest.list')); ?>">
                    <i class="fa fa-file"></i> <span>Withdrawal Request</span>
                    <?php if($withdrawalCount > 0): ?>
                        <small class="label pull-right bg-yellow"><?php echo e($withdrawalCount); ?></small>
                    <?php endif; ?>

                </a>

            </li>

            </li>
            


            <br>
            <br>
            <br>





        </ul>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const path = location.pathname;
            document.querySelectorAll('.sidebar-menu li a').forEach(a => {
                if (a.pathname === path) a.parentElement.classList.add('active');
            });
        });
    </script>


    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\laragon\www\goglyMart\logic-service\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>