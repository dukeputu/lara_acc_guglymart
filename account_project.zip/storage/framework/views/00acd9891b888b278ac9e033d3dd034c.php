
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="content-wrapper"> 

         <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            
            <?php echo $__env->yieldContent('title', 'MLM'); ?>
            <small>Preview</small>
          </h1>
         
        </section>

                <?php echo $__env->yieldContent('content'); ?>
           
    </div>

    
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php echo $__env->make('layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\goglyMart\MLMLara\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>