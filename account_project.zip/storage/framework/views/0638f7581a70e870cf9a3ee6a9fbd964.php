
<?php $__env->startSection('title', 'Package Master'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <!-- general form elements -->
                <div class="box box-primary">

                    <?php if(session('success')): ?>
                        <div class="flash-message flash-success">
                            <?php echo e(session('success')); ?>

                            <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="flash-message flash-error">
                            <ul style="margin-bottom: 0;">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                        </div>
                    <?php endif; ?>

                    


                    <form role="form" method="POST"
                        action="<?php echo e(isset($editPackage) ? route('packageMaster.update', $editPackage->id) : route('packageMaster.store')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($editPackage)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="box-body">
                            <p class="from-top-header">Package Master</p>
                            <div class="row">

                                <div class="form-group col-sm-12">
                                    <label>Package Name<sup>*</sup></label>
                                    <input type="text" class="form-control" name="package_name"
                                        value="<?php echo e(old('package_name', $editPackage->package_name ?? '')); ?>" required>
                                </div>

                                <div class="form-group col-sm-12">
                                    <label>Package Amount<sup>*</sup></label>
                                    <input min="1" type="number" class="form-control packageAmount"
                                        name="package_amount"
                                        value="<?php echo e(old('package_amount', $editPackage->package_amount ?? '')); ?>" required>
                                </div>

                                <div class="form-group col-sm-12">
                                    <label>Package %<sup>*</sup></label>
                                    <input min="1" type="number" class="form-control packagePer"
                                        name="package_payout_per"
                                        value="<?php echo e(old('package_payout_per', $editPackage->package_payout_per ?? '')); ?>"
                                        required>
                                </div>

                                <div class="form-group col-sm-12">
                                    <label>Total Amount<sup>*</sup></label>
                                    <input min="1" readonly type="number" class="form-control totalAmount"
                                        name="package_total_amount"
                                        value="<?php echo e(old('package_total_amount', $editPackage->package_total_amount ?? '')); ?>"
                                        required>
                                </div>

                                <div class="form-group col-sm-12">
                                    <label>Time Duration 29 month <sup>*</sup></label>
                                    <input min="1" type="number" class="form-control" name="package_time_duration"
                                        value="<?php echo e(old('package_time_duration', $editPackage->package_time_duration ?? 29)); ?>"
                                        readonly>
                                </div>

                                <div class="form-group col-sm-12">
                                    <label>Package Photo
                                        <sup>Size 512 x 512 px, Transparent Background Image is best</sup>
                                    </label>
                                    <?php if(isset($editPackage) && $editPackage->package_img): ?>
                                        <div class="mb-2">
                                            <img src="<?php echo e(asset($editPackage->package_img)); ?>" alt="Package Image"
                                                width="70">
                                        </div>
                                    <?php endif; ?>
                                    <input accept=".png,.webp" type="file" name="packagePhoto" class="form-control"
                                        onchange="if(this.files[0] && this.files[0].size > 512000){ alert('File must be 500 KB or smaller.'); this.value=''; }">
                                </div>

                            </div>

                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(isset($editPackage) ? 'Update' : 'Save'); ?>

                                </button>

                                <?php if(isset($editPackage)): ?>
                                    <a href="<?php echo e(route('packageMaster.list')); ?>" class="btn btn-secondary">Cancel</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>






                    <script>
                        document.addEventListener("input", () => {
                            const packageAmount = parseFloat(document.querySelector(".packageAmount")?.value) || 0;
                            const monthlyRate = parseFloat(document.querySelector(".packagePer")?.value) || 0;

                            // মাসিক payout = মূলধন × rate%
                            const monthlyReturn = packageAmount * monthlyRate / 100;

                            // Final return = মাসিক payout × 29 মাস
                            const finalAmount = monthlyReturn * 29;

                            // Output show
                            document.querySelector(".totalAmount").value = Math.round(finalAmount);
                        });
                    </script>



                </div><!-- /.box -->
            </div>



            <div class="col-md-8">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Package View</h3>
                        <input class="form-check-input" type="checkbox" role="switch" id="deleteSwitch">
                    </div><!-- /.box-header -->
                    <div class="box-body">
                        <table id="fileTable1" class="display responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL No</th>
                                    <th>Package Name</th>
                                    <th>Package Image</th>
                                    <th>Package Amount</th>
                                    <th>Package %</th>
                                    <th>Total Amount</th>
                                    <th>Time Duration</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($package->package_name); ?></td>
                                        <td> <?php
                                            $imgPath = public_path($package->package_img);
                                        ?>

                                            <?php if(file_exists($imgPath) && !empty($package->package_img)): ?>
                                                <img style="cursor: pointer;" src="<?php echo e(asset($package->package_img)); ?>"
                                                    alt="Screenshot" width="40" height="40" class="rounded border"
                                                    onclick="showScreenshot(this.src)" data-toggle="modal"
                                                    data-target="#ModalBasic1">
                                            <?php else: ?>
                                                <span>No Img</span>
                                            <?php endif; ?>


                                        </td>
                                        <td><?php echo e($package->package_amount); ?></td>
                                        <td><?php echo e($package->package_payout_per); ?> %</td>
                                        <td><?php echo e($package->package_amount); ?> + <?php echo e($package->package_payout_per); ?> % =
                                            <?php echo e($package->package_total_amount); ?></td>
                                        <td><?php echo e($package->package_time_duration); ?> Month</td>
                                        <td style="display: none;" class="plan-btn">

                                            <!-- Edit Button -->
                                            <a href="<?php echo e(route('packageMaster.edit', $package->id)); ?>"
                                                class="btn btn-warning btn-sm">
                                                <i class="fa fa-edit"></i>
                                            </a>


                                            <form
                                                action="<?php echo e(route('generic.delete', ['table' => 'package_master', 'id' => $package->id])); ?>"
                                                method="POST" style="display:inline-block;"
                                                onsubmit="return confirm('Are you sure want to delete <?php echo e($package->package_name); ?>?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div><!-- /.box-body -->
                </div>
            </div>

        </div>
    </section><!-- /.content -->

    <script>
        deleteSwitch.onchange = () =>
            document.querySelectorAll('.plan-btn').forEach(btn =>
                btn.style.display = deleteSwitch.checked ? 'block' : 'none'
            );
    </script>

    </div><!-- /.content-wrapper -->


    <!-- Modal -->
    <div class="modal fade" id="ModalBasic1" tabindex="-1" role="dialog" aria-labelledby="modalLabel1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <img style="max-width: 300px" id="modal-img" src="">
                </div>
            </div>
        </div>
    </div>



    <script>
        function showScreenshot(src) {
            document.getElementById('modal-img').src = src;
        }
    </script>








    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if($errors->any()): ?>
            toastr.error("<?php echo e($errors->first()); ?>");
        <?php endif; ?>
    </script>

    <script>
        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(el => {
                el.style.transition = "opacity 0.5s";
                el.style.opacity = 0;
                setTimeout(() => el.style.display = 'none', 500);
            });
        }, 4000);
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\trade-mania\resources\views/admin/logicApp/packageMaster.blade.php ENDPATH**/ ?>