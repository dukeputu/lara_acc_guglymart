
<?php $__env->startSection('title', 'Member Register'); ?>

<?php $__env->startSection('content'); ?>


<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">

                <?php if(session('success')): ?>
                <div class="flash-message flash-success">
                    <?php echo e(session('success')); ?>

                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="flash-message flash-error">
                    <ul style="margin-bottom: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
                <?php endif; ?>





                <form role="form" method="POST" action="<?php echo e(url('/member-register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <p class="from-top-header">Member Information</p>
                        <div class="row">

                            <!-- Introducer Section -->
                            <div class="form-group col-md-4">
                                <label> Enter Introduce ID or Phone</label>
                                <div style="display: flex;">
                                    <input type="number"  id="introducer_id"
                                        class="form-control">
                                    <input type="hidden" name="introducer_id_hidden" id="introducer_id_hidden">
                                    <button type="button" id="introduceIDBtn"
                                        class="btn btn-primary">Search</button>
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label>Introducer Name<sup>*</sup></label>
                                <input type="text" class="form-control" name="introducer_name" id="introducer_name"
                                    readonly>

                            </div>

                            <div class="form-group col-md-4">
                                <label>Introducer Phone No</label>
                                <input type="text" class="form-control" name="introducer_phone" id="introducer_phone"
                                    readonly>
                            </div>

                            <div class="form-group col-md-4">
                                <label>Introducer Full Address</label>
                                <input type="text" class="form-control" name="introducer_address"
                                    id="introducer_address" readonly>
                            </div>

                            <div class="form-group col-md-4">
                                <div class="radio">
                                    <label><input type="radio" id="position_left" name="position" value="Left" checked>
                                        Position Left</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <label><input type="radio" id="position_right" name="position" value="Right">
                                        Position Right</label>
                                </div>
                            </div>
                        </div>


                        <p class="from-top-header">Plan Information</p>
                        <div class="row">
                            <!-- select Plan -->
                            <div class="form-group col-md-4">
                                <label>Select Plan*</label>
                                <select name="select_plan_id" class="form-control" required>
                                    <option disabled selected>Select Plan</option>
                                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($plan->select_plan_id); ?>" data-name="<?php echo e($plan->select_plan); ?>">
                                        <?php echo e($plan->select_plan); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="select_plan_name" id="select_plan_name" value="">
                            </div>

                            <script>
                                document.addEventListener('DOMContentLoaded', function () {
                                    const select = document.querySelector('[name="select_plan_id"]');
                                    const hiddenInput = document.getElementById('select_plan_name');

                                    select.addEventListener('change', function () {
                                        const selected = select.options[select.selectedIndex];
                                        hiddenInput.value = selected.getAttribute('data-name');
                                    });
                                });
                            </script>


                        </div>

                        <!-- Member Section -->
                        <p class="from-top-header">Member Information</p>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label>Member ID<sup>*</sup></label>
                                <input type="text" class="form-control" value="MUM/<?php echo e($nextId); ?>" readonly>

                                <!-- Hidden field to store real value -->
                                <input type="hidden" name="member_id" value="<?php echo e($nextId); ?>">
                            </div>

                            <div class="form-group col-md-4">
                                <label>Name<sup>*</sup></label>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required>
                            </div>

                            <div class="form-group col-md-4">
                                <label>Phone No<sup>*</sup></label>
                                <input type="number" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>"
                                    required>
                            </div>

                            <div class="form-group col-md-4">
                                <label>Email Address</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                            </div>

                            <div class="form-group col-md-4">
                                <label>Full Address<sup>*</sup></label>
                                <input type="text" class="form-control" name="address" 
                                    value="<?php echo e(old('address')); ?>">
                            </div>

                            <div class="form-group col-md-4">
                                <label>Pin Code<sup>*</sup></label>
                                <input type="number" class="form-control" name="pincode" 
                                    value="<?php echo e(old('pincode')); ?>">
                            </div>

                            <div class="form-group col-md-4">
                                <label>State<sup>*</sup></label>
                                <input type="text" class="form-control" name="state" 
                                    value="<?php echo e(old('state')); ?>">
                            </div>

                            <div class="form-group col-md-4">
                                <label>District<sup>*</sup></label>
                                <input type="text" class="form-control" name="district" 
                                    value="<?php echo e(old('district')); ?>">
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </form>








            </div><!-- /.box -->



        </div>

    </div>
</section><!-- /.content -->

</div><!-- /.content-wrapper -->




<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if($errors -> any()): ?>
        toastr.error("<?php echo e($errors->first()); ?>");
    <?php endif; ?>
</script>

<script>
    setTimeout(() => {
        document.querySelectorAll('.flash-message').forEach(el => {
            el.style.transition = "opacity 0.5s";
            el.style.opacity = 0;
            setTimeout(() => el.style.display = 'none', 500);
        });
    }, 4000);
</script>



<script>
    $(document).ready(function () {
        $('#introduceIDBtn').click(function () {
        // $('#introducer_id').focusout(function () {
            var id = $('#introducer_id').val();

            if (id) {
                $.get('/get-introducer/' + id, function (data) {
                    if (data && data.name) {
                        $('#introducer_id_hidden').val(data.introducer_id_hidden);
                        $('#introducer_name').val(data.name);
                        $('#introducer_phone').val(data.phone);
                        $('#introducer_address').val(data.address);

                        // Set Position radio button
                        if (data.position === 'Left') {
                            $('#position_left').prop('checked', true);
                        } else if (data.position === 'Right') {
                            $('#position_right').prop('checked', true);
                        }
                    } else {
                        alert('Introducer not found');
                    }
                }).fail(function () {
                    alert('Something went wrong');
                });
            } else {
                // alert('Please enter Introducer ID');
            }
        });
    });
</script>
<?php echo $__env->make('layouts.fontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\MLMLara\backend\resources\views/fontend/font_member_join.blade.php ENDPATH**/ ?>