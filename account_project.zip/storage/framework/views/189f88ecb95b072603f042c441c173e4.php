
<?php $__env->startSection('title', 'App User List'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Main content -->
    <section class="content">
        <div class="row">

            <div class="col-md-12">
                <div class="box">
                    <div class="box-header">
                        



                    </div><!-- /.box-header -->
                    <div class="box-body">
                        <table id="fileTable1" class="display responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL No</th>
                                    
                                    <th>Category</th>
                                    <th>Loan</th>
                                    <th>Interest</th>
                                    <th>Final</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        
                                        <td><?php echo e($plan->business_category_name); ?></td>
                                        <td><?php echo e($plan->loan_amount); ?></td>
                                        <td><?php echo e($plan->interest_rate); ?>%</td>
                                        <td><?php echo e($plan->final_amount); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('business.plan.toggle', $plan->id)); ?>"
                                                class="btn btn-sm <?php echo e($plan->status == 1 ? 'btn-danger' : 'btn-success'); ?>">
                                                <?php echo e($plan->status == 1 ? '✅ Active' : '❌ Inactive'); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('business.plan.edit', $plan->id)); ?>"
                                                class="btn btn-primary btn-sm">✏️ Edit</a>
                                            <a href="<?php echo e(route('business.plan.delete', $plan->id)); ?>"
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete this plan?')">🗑
                                                Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>



                    </div>
                </div>
            </div>

        </div>
    </section>
    </div>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if($errors->any()): ?>
            toastr.error("<?php echo e($errors->first()); ?>");
        <?php endif; ?>
    </script>

    <script>
        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(el => {
                el.style.transition = "opacity 0.5s";
                el.style.opacity = 0;
                setTimeout(() => el.style.display = 'none', 500);
            });
        }, 4000);
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\account_project\resources\views/admin/users/businessPlanView.blade.php ENDPATH**/ ?>