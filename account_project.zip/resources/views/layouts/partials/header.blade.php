  <body class="skin-blue">
      <div class="wrapper">
          {{-- <style>
              .skin-blue .main-header .logo {
                  background-color: #3c8dbc;
                  color: #fff;
                  border-bottom: 0 solid transparent;
              }
          </style> --}}
         
