 <footer class="modern-header" style=" top: unset; ">
        <div class="pull-right hidden-xs">
          <b>Version</b> 8.2721
        </div>
        <strong>Copyright &copy; 2025-2026.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->
 