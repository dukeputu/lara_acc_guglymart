
@include('userApp.layouts.partials.head')

@include('userApp.layouts.partials.header')

                @yield('content')
 
    {{-- Footer --}}
@include('userApp.layouts.partials.footer')


